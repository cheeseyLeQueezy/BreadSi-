import time
#Baking sim

#Variables:
canLoad = True

CookingLV = 1

dabloons = 0

inv = []
upgrades = ["speed:"]

cookSpeed = 1

colour = True
#recipes:
water = False

breadR = ["dough"]
coisonR = ["dough"]
baggetR = ["dough"]
#Start::

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

print(bcolors.WARNING + "Use 'help' to see a list of all commands available")
print(bcolors.ENDC)

def CommandsList():
    print("""
|| flour > basic ingredient 1 to make dough
|| water > basic ingrediant 2! ^^^
|| dough > obtains dough
|| cook > once you have dough, cook it for bread

|| sell > sell desired object
|| upgrade > allows for upgrades + list"
|| inv > allows to see inventory(stash, dabloons, upgrades)"

|| settings > view settings
|| end > stops program - exits program
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
|| RECIPES:
|| > flour + water = dough
    > Cooked: Bread
|| > dough + flour = kneeded dough
    > Cooked: Croissant
|| > kneeded dough + flour + water = rolled dough 
    > Cooked: Baguette
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
|| SELL PRICES: (Dabloons)
|| > Dough = 0.5
|| > Bread = 1
|| > Croissant = 2
|| > Baguette = 4
    """)

def Settings():
    global colour
    print("Colour:", colour)
    x = input("What do you want to change?  ")
    if x == "colour":
        y = input("T/F ?")
        if y == "T":
            colour = True
            print("[colour set to true]")
        elif y == "F":
            colour = False
            print("[colour set to false]")

def Load(type):
    global canLoad
    if type == "cooking":
        if colour == True:
            print(bcolors.FAIL + "cooking.")
            time.sleep(cookSpeed)
            print(bcolors.FAIL + "cooking..")
            time.sleep(cookSpeed)
            print(bcolors.FAIL + "cooking...")
        else:
            print("cooking.")
            time.sleep(cookSpeed)
            print("cooking..")
            time.sleep(cookSpeed)
            print("cooking...")
            time.sleep(cookSpeed)

    if type == "kneed":
        if colour == True:
            print(bcolors.FAIL + "kneed.")
            time.sleep(cookSpeed)
            print(bcolors.FAIL + "kneed..")
            time.sleep(cookSpeed)
            print(bcolors.FAIL + "kneed...")
        else:
            print("kneed.")
            time.sleep(cookSpeed)
            print("kneed..")
            time.sleep(cookSpeed)
            print("kneed...")
            time.sleep(cookSpeed)
    print(bcolors.ENDC)
    canLoad = True

def Sell(food):
    global dabloons
    if food == "all":
        all = 0
        if "bread" in inv:
            dabloons += 1
            all += 1
        elif "dough" in inv:
            dabloons += 0.5
            all += 0.5
        elif "croissant" in inv:
            dabloons += 2
            all += 2
        elif "baguette" in inv:
            dabloons += 4
            all += 4
    if colour == True:
        print(bcolors.OKGREEN + f"sold all! || {all} dabloons")
    else:
        print(f"sold all! || {all} dabloons")

    if food == "bread":
        if "bread" in inv:
            inv.remove("bread")
            if colour == True:
                print(bcolors.OKGREEN + "sold bread || + 1 dabloons")
            else:
                print("sold bread || + 1 dabloons")
            dabloons += 1
        else:
            print("No bread in inventory!")
    if food == "dough":
        if "dough" in inv:
            inv.remove("dough")
            if colour == True:
                print(bcolors.OKGREEN + "sold dough || + 0.5 dabloons")
            else:
                print("sold dough || + 0.5 dabloons")
            dabloons += 0.5
        else:
            print("No dough in inventory!")
    if food == "croissant":
        if "croissant" in inv:
            inv.remove("croissant")
            if colour == True:
                print(bcolors.OKGREEN + "sold croissant || + 2 dabloons")
            else:
                print("sold croissant || + 2 dabloons")
            dabloons += 2
        else:
            print("No croissant in inventory!")
    if food == "baguette":
        if "baguette" in inv:
            inv.remove("baguette")
            if colour == True:
                print(bcolors.OKGREEN + "sold baguette || + 4 dabloons")
            else:
                print("sold baguette || + 4 dabloons")
            dabloons += 2
        else:
            print("No baguette in inventory!")
    print(bcolors.ENDC)

def Upgrade(type):
    global cookSpeed
    global CookingLV
    global dabloons
    if type == "cook speed":
        if dabloons >= 5:
            dabloons -= 5
            cookSpeed -= 0.25
            if colour == True:
                print(bcolors.OKGREEN + "Cooking speed has decreased -0.25 seconds")
                print(bcolors.FAIL + "-5 dabloons")
            else:
                print("Cooking speed has decreased -0.25 seconds")
                print("-5 dabloons")
            CookingLV += 1
        else:
            if colour == True:
                print(bcolors.FAIL + "Not enough dabloons!")
            else:
                print("Not enough dabloons!")
    print(bcolors.ENDC)
        

while True:
    ingred = input("?:  ")
    if ingred == "cook":
        if "dough" in inv:
            Load(type = "cooking")
            print("bread")
            inv.remove("dough")
            inv.append("bread")
            #print(ingred)
        if "kneeded-dough" in inv:
            Load(type = "cooking")
            print("croissant")
            inv.remove("kneeded-dough")
            inv.append("croissant")
        if "rolled-dough" in inv:
            Load(type = "cooking")
            print("baguette")
            inv.remove("rolled-dough")
            inv.append("baguette")
    
    if ingred == "kneed":
        if "kneeded-dough" in inv and "water" in inv and "flour":
            Load(type = "kneed")
            print("rolled dough")
            inv.remove("kneeded-dough")
            inv.remove("flour")
            inv.remove("water")
            inv.append("rolled-dough")
            print("Rolled dough")
            water = False
        if "flour" in inv and "water" in inv:
            Load(type = "kneed")
            inv.remove("flour")
            inv.remove("water")
            inv.append("dough")
            print("Dough")
            water = False
        if "dough" in inv and "flour" in inv:
            Load(type = "kneed")
            print("kneeded dough")
            inv.remove("dough")
            inv.remove("flour")
            inv.append("kneeded-dough")
            print("Kneeded dough")
            water = False
    if ingred == "sell":
        x = input("what do you want to sell?  ")
        Sell(food = x)
    if ingred == "upgrade":
        print("""
||Cooking upgrade cost: 5 dabloons ("speed")
    """)
        x = input("what do you want to upgrade?  ")
        Upgrade(type = x)
    if ingred == "inv":
        print(inv, "<<< Stash")
        print(dabloons, "dabloons")
        print(upgrades, CookingLV, "<<< Upgrades")
    if ingred == "water":
        if water == True:
            print("you already have water")
        else:
            water = True
            inv.append("water")
            print("Water")
    if ingred == "flour":
        inv.append("flour")
        print("Flour")

    
    if ingred == "settings":
        Settings()
    if ingred == "help":
        CommandsList()
    if ingred == "end":
        break

