import time
#Baking sim

#Variables:
CookingLV = 1

dabloons = 0

inv = []
upgrades = ["Cooking speed:"]

cookSpeed = 1

#recipes:

#Start::

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

print(bcolors.WARNING + "Use 'help' to see a list of all commands available")
print(bcolors.ENDC)

def CommandsList():
    print("""
|| dough > obtains dough
|| cook > once you have dough, cook it for bread

|| sell > sell desired object
|| upgrade > allows for upgrades + list"
|| inv > allows to see inventory(stash, dabloons, upgrades)"

|| end > stops program - exits program
    """)

def Load(type):
    if type == "cooking":
        print(bcolors.FAIL + "cooking.")
        time.sleep(cookSpeed)
        print(bcolors.FAIL + "cooking..")
        time.sleep(cookSpeed)
        print(bcolors.FAIL + "cooking...")
        time.sleep(cookSpeed)
    print(bcolors.ENDC)

def Sell(food):
    global dabloons
    if food == "bread":
        if "bread" in inv:
            inv.remove("bread")
            print(bcolors.OKGREEN + "sold bread || + 1 dabloons")
            dabloons += 1
        else:
            print("No bread in inventory!")
    if food == "dough":
        if "dough" in inv:
            inv.remove("dough")
            print(bcolors.OKGREEN + "sold dough || + 0.5 dabloons")
            dabloons += 0.5
        else:
            print("No bread in inventory!")
    print(bcolors.ENDC)

def Upgrade(type):
    global cookSpeed
    global CookingLV
    global dabloons
    if type == "cook speed":
        if dabloons >= 5:
            dabloons -= 5
            cookSpeed -= 0.25
            print(bcolors.OKGREEN + "Cooking speed has decreased -0.25 seconds")
            print(bcolors.FAIL + "-5 dabloons")
            CookingLV += 1
        else:
            print(bcolors.FAIL + "Not enough dabloons!")
    print(bcolors.ENDC)
        

while True:
    ingred = input("?:  ")
    if ingred == "cook":
        if "dough" in inv:
            Load(type = "cooking")
            print("bread")
            inv.remove("dough")
            inv.append("bread")
            #print(ingred)
    if ingred == "sell":
        x = input("what do you want to sell?  ")
        Sell(food = x)
    if ingred == "upgrade":
        print("""
||Cooking upgrade cost: 5 dabloons
    """)
        x = input("what do you want to upgrade?  ")
        Upgrade(type = x)
    if ingred == "inv":
        print(inv, "<<< Stash")
        print(dabloons, "dabloons")
        print(upgrades, CookingLV, "<<< Upgrades")
    if ingred == "dough":
        inv.append("dough")
        
    if ingred == "help":
        CommandsList()
    if ingred == "end":
        break

